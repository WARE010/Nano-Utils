🇷🇺 # Nano Utils

Nano Utils - это легковесная библиотека вспомогательных утилит на Java, предназначенная для упрощения повседневных задач разработки. Она предоставляет набор статических методов, организованных по категориям, для работы со строками, датами, коллекциями, файлами и другими общими операциями.

## Особенности

- Компактность: Nano Utils спроектирован как легковесная библиотека с минимальными зависимостями, что обеспечивает быструю интеграцию и низкие накладные расходы.
- Простота использования: Благодаря статическим методам, организованным по категориям, использование Nano Utils интуитивно понятно и не требует создания экземпляров классов.
- Расширяемость: Модульная структура библиотеки позволяет легко добавлять новые утилитные классы и методы по мере необходимости.

## Установка

Для использования Nano Utils в своем проекте, просто скачайте новую версию библиотеки в расширении .jar, далее поместите библиотеку в папку libs вашего проекта, и укажите нужные зависимости в pom.xml или build.gradle

Или, если вы используете Maven или Gradle, добавьте следующую зависимость в ваш файл сборки:

<!-- Maven -->
<dependency>
    <groupId>com.npstudio</groupId>
    <artifactId>nano-utils</artifactId>
    <version>1.0.0</version>
</dependency>

// Gradle
implementation 'com.npstudio:nano-utils:1.0.0'

## Использование

После установки библиотеки, вы можете импортировать необходимые утилитные классы и начать использовать их методы. Например:

import com.npstudio.nanoutils.StringUtils;

public class Example {
    public static void main(String[] args) {
        String input = "   Hello, World!   ";
        String trimmed = StringUtils.trim(input); // "Hello, World!"
        System.out.println(trimmed);
    }
}

## Документация

Подробная документация по всем доступным классам и методам в Nano Utils находится в разработке. Пока ознакомьтесь с исходным кодом библиотеки для получения информации о текущем функционале.

## Вклад

Мы приветствуем любые вклады в развитие Nano Utils. Если у вас есть идеи по улучшению или вы нашли ошибку, пожалуйста, создайте соответствующий issue или отправьте pull request.

## Лицензия

Nano Utils распространяется под лицензией MIT. Подробности можно найти в файле [LICENSE](LICENSE).

---

🇬🇧 # Nano Utils

Nano Utils is a lightweight Java utility library designed to simplify everyday development tasks. It provides a set of static methods, organized by category, for working with strings, dates, collections, files, and other common operations.

## Features

- Compact: Nano Utils is designed as a lightweight library with minimal dependencies, allowing for fast integration and low overhead.
- Ease of Use: With static methods organized by category, using Nano Utils is intuitive and does not require creating class instances.
- Extensibility: The modular structure of the library makes it easy to add new utility classes and methods as needed.

## Installation

To use Nano Utils in your project, simply download the new version of the library in the .jar extension, then place the library in the libs folder of your project, and specify the necessary dependencies in pom.xml or build.gradle

Or, if you're using Maven or Gradle, add the following dependency to your build file:

<!-- Maven -->
<dependency>
    <groupId>com.npstudio</groupId>
    <artifactId>nano-utils</artifactId>
    <version>1.0.0</version>
</dependency>

// Gradle
implementation 'com.npstudio:nano-utils:1.0.0'

## Usage

After installing the library, you can import the necessary utility classes and start using their methods. For example:

import com.npstudio.nanoutils.StringUtils;

public class Example {
    public static void main(String[] args) {
        String input = "   Hello, World!   ";
        String trimmed = StringUtils.trim(input); // "Hello, World!"
        System.out.println(trimmed);
    }
}

## Documentation

Detailed documentation for all available classes and methods in Nano Utils is under development. For now, check out the library's source code for information on current functionality.

## Contribution

We welcome any contributions to the development of Nano Utils. If you have ideas for improvement or find a bug, please create an appropriate issue or send a pull request.

## License

Nano Utils is licensed under the MIT License. Details can be found in the [LICENSE](LICENSE) file.