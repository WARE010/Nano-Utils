package com.npstudio.nanoutils;

public class StringUtils {
    public static String capitalizeFirstLetter(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    public static boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }
}