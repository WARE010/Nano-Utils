package com.npstudio.nanoutils;

import java.util.ArrayList;
import java.util.List;

public class CollectionUtils {

    public static <T> List<T> createList(T... elements) {
        List<T> list = new ArrayList<>();
        for (T element : elements) {
            list.add(element);
        }
        return list;
    }

    public static <T> List<T> addAllDistinct(List<T> list, T... elements) {
        List<T> distinct = new ArrayList<>(list);
        for (T element : elements) {
            if (!distinct.contains(element)) {
                distinct.add(element);
            }
        }
        return distinct;
    }

    public static <T> boolean containsDuplicates(List<T> list) {
        List<T> distinct = new ArrayList<>(list);
        distinct = addAllDistinct(distinct);
        return distinct.size() != list.size();
    }

    public static <T> List<T> removeDuplicates(List<T> list) {
        return addAllDistinct(new ArrayList<T>(), list.toArray(new ArrayList<T>().toArray((T[]) new Object[0])));
    }
}