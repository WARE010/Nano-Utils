package com.npstudio.nanoutils;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class DateUtils {
    public static int calculateAge(LocalDate birthDate) {
        return (int) ChronoUnit.YEARS.between(birthDate, LocalDate.now());
    }

    public static Period getPeriodBetween(LocalDate startDate, LocalDate endDate) {
        return Period.between(startDate, endDate);
    }
}