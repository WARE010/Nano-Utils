package com.npstudio.nanoutils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ResourceUtils {

    public static String readResourceAsString(String resourcePath) throws IOException {
        InputStream inputStream = ResourceUtils.class.getClassLoader().getResourceAsStream(resourcePath);
        if (inputStream == null) {
            throw new IOException("Resource not found: " + resourcePath);
        }
        byte[] buffer = new byte[inputStream.available()];
        inputStream.read(buffer);
        inputStream.close();
        return new String(buffer);
    }

    public static Properties loadProperties(String resourcePath) throws IOException {
        Properties properties = new Properties();
        InputStream inputStream = ResourceUtils.class.getClassLoader().getResourceAsStream(resourcePath);
        if (inputStream == null) {
            throw new IOException("Resource not found: " + resourcePath);
        }
        properties.load(inputStream);
        inputStream.close();
        return properties;
    }
}