package com.npstudio.nanoutils;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class NetworkUtils {

    public static boolean isInternetAvailable() {
        try {
            HttpURLConnection conn = (HttpURLConnection) new URL("http://www.google.com").openConnection();
            conn.setRequestMethod("HEAD");
            int responseCode = conn.getResponseCode();
            return responseCode >= 200 && responseCode < 400;
        } catch (IOException e) {
            return false;
        }
    }

    public static String getLocalIpAddress() throws IOException {
        InetAddress ip = InetAddress.getLocalHost();
        return ip.getHostAddress();
    }
}