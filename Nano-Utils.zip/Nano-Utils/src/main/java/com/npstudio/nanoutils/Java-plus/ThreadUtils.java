package com.npstudio.nanoutils;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadUtils {

    private static final ScheduledExecutorService executorService = Executors.newScheduledThreadPool(10);

    public static void runInBackground(Runnable task) {
        executorService.execute(task);
    }

    public static void scheduleAtFixedRate(Runnable task, long initialDelay, long period, TimeUnit unit) {
        executorService.scheduleAtFixedRate(task, initialDelay, period, unit);
    }
}